import pytest
from app import create_app
from app.extensions import db
from app.models import Student, User

@pytest.fixture()
def app(tmp_path):
    app=create_app({"TESTING":True,"WTF_CSRF_ENABLED":False,"SQLALCHEMY_DATABASE_URI":f"sqlite:///{tmp_path/'test.db'}","SECRET_KEY":"test"})
    with app.app_context():
        db.create_all()
        admin=User(name="Admin",email="admin@example.com",role="admin"); admin.set_password("correct-password")
        user=User(name="Student user",email="user@example.com",role="student"); user.set_password("correct-password")
        student=Student(student_id="ST-001",full_name="Student user",email="student@example.com",department="CSE",program="BSc",semester="1st",user=user)
        db.session.add_all([admin,user,student]);db.session.commit()
        yield app
        db.session.remove();db.drop_all()
@pytest.fixture()
def client(app): return app.test_client()
def login(client,email): return client.post('/login',data={'email':email,'password':'correct-password'},follow_redirects=True)
@pytest.fixture()
def admin_client(client): login(client,'admin@example.com');return client
@pytest.fixture()
def student_client(client): login(client,'user@example.com');return client
