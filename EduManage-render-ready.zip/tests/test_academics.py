from datetime import date
from app.extensions import db
from app.models import Attendance, Course, Enrollment, Result, Student
from app.utils import grade_for
def test_grading_scale():
    assert grade_for(80)=="A+" and grade_for(33)=="D" and grade_for(32.9)=="F"
def test_duplicate_enrollment_is_rejected(app):
    with app.app_context():
        s=Student.query.first(); c=Course(code='CSE101',title='Intro',department='CSE',credit_hours=3,semester='1st',instructor_name='Ada')
        db.session.add(c);db.session.commit();db.session.add(Enrollment(student_id=s.id,course_id=c.id));db.session.commit()
        db.session.add(Enrollment(student_id=s.id,course_id=c.id))
        try: db.session.commit(); assert False
        except Exception: db.session.rollback()
def test_attendance_percentage_rule(app):
    with app.app_context():
        s=Student.query.first(); c=Course(code='CSE102',title='DB',department='CSE',credit_hours=3,semester='1st',instructor_name='Ada');db.session.add(c);db.session.commit()
        db.session.add_all([Attendance(student_id=s.id,course_id=c.id,date=date(2026,1,1),status='Present'),Attendance(student_id=s.id,course_id=c.id,date=date(2026,1,2),status='Late'),Attendance(student_id=s.id,course_id=c.id,date=date(2026,1,3),status='Absent')]);db.session.commit()
        records=Attendance.query.all();assert round(100*sum(r.status in ('Present','Late') for r in records)/len(records),1)==66.7
def test_marks_bounds(admin_client):
    response=admin_client.post('/admin/results',data={'student_id':1,'course_id':99,'assessment_type':'Midterm','term':'Spring','marks_obtained':'120','maximum_marks':'100'},follow_redirects=True)
    assert b'Could not save result' in response.data
