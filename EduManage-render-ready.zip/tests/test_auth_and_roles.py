def test_invalid_login(client):
    response=client.post('/login',data={'email':'admin@example.com','password':'wrong'})
    assert b'Invalid email or password' in response.data
def test_admin_route_requires_login(client):
    assert client.get('/admin/dashboard').status_code in (301,302)
def test_student_cannot_access_admin(student_client):
    assert student_client.get('/admin/dashboard').status_code == 403
def test_student_sees_personal_portal(student_client):
    response=student_client.get('/student/dashboard')
    assert response.status_code == 200 and b'Student user' in response.data
def test_logout(client):
    client.post('/login',data={'email':'admin@example.com','password':'correct-password'})
    client.post('/logout')
    assert client.get('/admin/dashboard').status_code in (301,302)
