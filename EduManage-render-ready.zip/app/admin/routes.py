import csv
from datetime import date
from io import StringIO
from flask import Blueprint, Response, flash, redirect, render_template, request, url_for
from sqlalchemy import or_
from ..extensions import db
from ..models import Attendance, Course, Enrollment, Result, Setting, Student
from ..utils import grade_for, role_required

bp = Blueprint("admin", __name__, url_prefix="/admin")
def field(name): return request.form.get(name, "").strip()
def student_values(student):
    student.student_id=field("student_id"); student.full_name=field("full_name"); student.email=field("email").lower(); student.phone=field("phone")
    student.department=field("department"); student.program=field("program"); student.semester=field("semester"); student.status=field("status") or "Active"
def course_values(course):
    course.code=field("code").upper(); course.title=field("title"); course.department=field("department"); course.semester=field("semester"); course.instructor_name=field("instructor_name"); course.description=field("description")
    course.credit_hours=int(field("credit_hours") or 0)
@bp.get("/dashboard")
@role_required("admin")
def dashboard():
    return render_template("admin/dashboard.html", total_students=Student.query.count(), total_courses=Course.query.count(), active_enrollments=Enrollment.query.count(), recent_students=Student.query.order_by(Student.id.desc()).limit(5).all(), recent_results=Result.query.order_by(Result.id.desc()).limit(5).all())
@bp.route("/students", methods=["GET", "POST"])
@role_required("admin")
def students():
    if request.method == "POST":
        try:
            s=Student(); student_values(s)
            if not s.student_id or not s.full_name or not s.email: raise ValueError("Student ID, full name, and email are required.")
            db.session.add(s); db.session.commit(); flash("Student created.", "success")
        except Exception as exc:
            db.session.rollback(); flash("Could not create student. Check duplicate ID/email and required fields.", "danger")
        return redirect(url_for("admin.students"))
    q=request.args.get("q", "").strip(); query=Student.query
    if q: query=query.filter(or_(Student.full_name.ilike(f"%{q}%"), Student.student_id.ilike(f"%{q}%"), Student.email.ilike(f"%{q}%")))
    page=query.order_by(Student.id.desc()).paginate(page=request.args.get("page", 1, type=int), per_page=10, error_out=False)
    return render_template("admin/students.html", students=page.items, page=page, q=q)
@bp.route("/students/<int:student_id>", methods=["GET", "POST"])
@role_required("admin")
def student_detail(student_id):
    s=db.get_or_404(Student, student_id)
    if request.method == "POST":
        try: student_values(s); db.session.commit(); flash("Student updated.", "success")
        except Exception: db.session.rollback(); flash("Could not update student. ID and email must remain unique.", "danger")
        return redirect(url_for("admin.student_detail", student_id=s.id))
    return render_template("admin/student_detail.html", student=s)
@bp.post("/students/<int:student_id>/delete")
@role_required("admin")
def delete_student(student_id):
    s=db.get_or_404(Student, student_id); db.session.delete(s); db.session.commit(); flash("Student deleted.", "success"); return redirect(url_for("admin.students"))
@bp.route("/courses", methods=["GET", "POST"])
@role_required("admin")
def courses():
    if request.method == "POST":
        try:
            c=Course(); course_values(c)
            if not c.code or not c.title or c.credit_hours < 1: raise ValueError()
            db.session.add(c); db.session.commit(); flash("Course created.", "success")
        except Exception: db.session.rollback(); flash("Could not create course. Course code must be unique and credits valid.", "danger")
        return redirect(url_for("admin.courses"))
    q=request.args.get("q", ""); query=Course.query
    if q: query=query.filter(or_(Course.code.ilike(f"%{q}%"), Course.title.ilike(f"%{q}%")))
    return render_template("admin/courses.html", courses=query.order_by(Course.code).all(), q=q)
@bp.route("/courses/<int:course_id>", methods=["GET", "POST"])
@role_required("admin")
def course_detail(course_id):
    c=db.get_or_404(Course, course_id)
    if request.method == "POST":
        try:
            course_values(c)
            if not c.code or not c.title or c.credit_hours < 1: raise ValueError()
            db.session.commit(); flash("Course updated.", "success")
        except Exception:
            db.session.rollback(); flash("Could not update course. Course code must be unique and credits valid.", "danger")
        return redirect(url_for("admin.course_detail", course_id=c.id))
    return render_template("admin/course_detail.html", course=c)
@bp.post("/courses/<int:course_id>/delete")
@role_required("admin")
def delete_course(course_id):
    c=db.get_or_404(Course, course_id)
    if c.enrollments: flash("Cannot delete a course with enrollments. Remove enrollments first.", "warning")
    else: db.session.delete(c); db.session.commit(); flash("Course deleted.", "success")
    return redirect(url_for("admin.courses"))
@bp.route("/enrollments", methods=["GET", "POST"])
@role_required("admin")
def enrollments():
    if request.method == "POST":
        sid=request.form.get("student_id", type=int); cid=request.form.get("course_id", type=int)
        if not sid or not cid or Enrollment.query.filter_by(student_id=sid, course_id=cid).first(): flash("Select a new student/course pair.", "danger")
        else: db.session.add(Enrollment(student_id=sid, course_id=cid)); db.session.commit(); flash("Enrollment created.", "success")
        return redirect(url_for("admin.enrollments"))
    return render_template("admin/enrollments.html", enrollments=Enrollment.query.order_by(Enrollment.id.desc()).all(), students=Student.query.order_by(Student.full_name).all(), courses=Course.query.order_by(Course.code).all())
@bp.post("/enrollments/<int:enrollment_id>/delete")
@role_required("admin")
def delete_enrollment(enrollment_id):
    db.session.delete(db.get_or_404(Enrollment, enrollment_id)); db.session.commit(); flash("Enrollment removed.", "success"); return redirect(url_for("admin.enrollments"))
@bp.route("/attendance", methods=["GET", "POST"])
@role_required("admin")
def attendance():
    courses=Course.query.order_by(Course.code).all(); selected=request.values.get("course_id", type=int); selected_date=request.values.get("date", date.today().isoformat())
    if request.method == "POST":
        records=Enrollment.query.filter_by(course_id=selected).all()
        for e in records:
            status=request.form.get(f"status_{e.student_id}", "Present")
            record=Attendance.query.filter_by(student_id=e.student_id, course_id=selected, date=date.fromisoformat(selected_date)).first()
            if not record: record=Attendance(student_id=e.student_id, course_id=selected, date=date.fromisoformat(selected_date)); db.session.add(record)
            record.status=status
        db.session.commit(); flash("Attendance saved.", "success"); return redirect(url_for("admin.attendance", course_id=selected, date=selected_date))
    enrolled=Enrollment.query.filter_by(course_id=selected).all() if selected else []
    existing={(r.student_id):r.status for r in Attendance.query.filter_by(course_id=selected, date=date.fromisoformat(selected_date)).all()} if selected else {}
    return render_template("admin/attendance.html", courses=courses, selected=selected, selected_date=selected_date, enrolled=enrolled, existing=existing)
@bp.route("/results", methods=["GET", "POST"])
@role_required("admin")
def results():
    if request.method == "POST":
        try:
            marks=float(field("marks_obtained")); maximum=float(field("maximum_marks"))
            if maximum <= 0 or marks < 0 or marks > maximum: raise ValueError()
            result=Result(student_id=request.form.get("student_id", type=int), course_id=request.form.get("course_id", type=int), assessment_type=field("assessment_type"), term=field("term"), marks_obtained=marks, maximum_marks=maximum, grade=grade_for(marks/maximum*100), remarks=field("remarks"))
            db.session.add(result); db.session.commit(); flash("Result recorded.", "success")
        except Exception: db.session.rollback(); flash("Could not save result. Ensure marks and assessment are valid and unique.", "danger")
        return redirect(url_for("admin.results"))
    return render_template("admin/results.html", results=Result.query.order_by(Result.id.desc()).all(), students=Student.query.order_by(Student.full_name).all(), courses=Course.query.order_by(Course.code).all())
@bp.get("/reports")
@role_required("admin")
def reports(): return render_template("admin/reports.html", students=Student.query.all(), courses=Course.query.all())
@bp.get("/reports/students.csv")
@role_required("admin")
def students_csv():
    out=StringIO(); writer=csv.writer(out); writer.writerow(["Student ID", "Name", "Email", "Department", "Semester", "Status"])
    for s in Student.query.order_by(Student.full_name): writer.writerow([s.student_id,s.full_name,s.email,s.department,s.semester,s.status])
    return Response(out.getvalue(), mimetype="text/csv", headers={"Content-Disposition":"attachment; filename=students.csv"})
@bp.route("/settings", methods=["GET", "POST"])
@role_required("admin")
def settings():
    if request.method == "POST":
        setting=Setting.query.get("attendance_late_counts_present") or Setting(key="attendance_late_counts_present", value="true")
        setting.value="true" if request.form.get("late_counts") else "false"; db.session.add(setting); db.session.commit(); flash("Settings updated.", "success")
    setting=Setting.query.get("attendance_late_counts_present")
    return render_template("admin/settings.html", late_counts=not setting or setting.value=="true")
