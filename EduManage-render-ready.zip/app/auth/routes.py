from pathlib import Path
from flask import Blueprint, flash, redirect, render_template, request, send_from_directory, session, url_for
from ..models import User
from ..extensions import db

bp = Blueprint("auth", __name__)
@bp.route("/")
def home(): return redirect(url_for("auth.login"))
@bp.route("/showcase")
def showcase(): return send_from_directory(Path(__file__).resolve().parents[2], "showcase.html")
@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower(); password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        if not user or not user.check_password(password):
            flash("Invalid email or password.", "danger")
        else:
            session.clear(); session["user_id"] = user.id
            return redirect(url_for("admin.dashboard") if user.role == "admin" else url_for("student.dashboard"))
    return render_template("auth/login.html")
@bp.post("/logout")
def logout():
    session.clear(); flash("You have been signed out.", "success"); return redirect(url_for("auth.login"))
