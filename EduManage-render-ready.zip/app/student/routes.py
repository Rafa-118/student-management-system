from flask import Blueprint, render_template
from ..models import Attendance, Result
from ..utils import current_user, role_required

bp=Blueprint("student", __name__, url_prefix="/student")
@bp.get("/dashboard")
@role_required("student")
def dashboard():
    student=current_user().student
    records=Attendance.query.filter_by(student_id=student.id).all()
    attendance=round(100*sum(r.status in ("Present","Late") for r in records)/len(records), 1) if records else 0
    return render_template("student/dashboard.html", student=student, enrollments=student.enrollments, attendance=attendance, results=Result.query.filter_by(student_id=student.id).all())
